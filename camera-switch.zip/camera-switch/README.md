# Switching between different AR cameras demo

![Preview](previews/preview.webp?raw=true "Preview")

To successfully run in 
- Select 8thwall as a framework in the editor `Project Settings -> VR & AR -> framework`.
- Paste in your 8th Wall API key.
- Make sure the app is running on HTTPS.